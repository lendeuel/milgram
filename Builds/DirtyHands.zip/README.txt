1. Extract all of the Files here and put them inside the same folder. 
2. Then press on the DirtyHands EXE. 
